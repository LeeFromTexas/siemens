flir_ptu
========

Basic serial ROS driver for FLIR PTUs. Currently tested with:

 - [FLIR D46](http://www.flir.com/mcs/view/?id=53707)


License
=======

This repo originated at [Washington University](https://wu-robotics.googlecode.com/svn/branches/stable/wu_ptu),
where the code was licensed as GPLv2. The initial copy was made at svn revision r2226.

Thanks to Nick Hawes (@hawesie) for the first pass at catkinizing this repo.
