#ifndef crypto_int32_h
#define crypto_int32_h

typedef int crypto_int32;

#endif
